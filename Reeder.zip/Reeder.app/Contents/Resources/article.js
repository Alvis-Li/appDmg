var reeder = {
    
contentWidth: 0,
bodyWidth: 0,
contentLeft: 0,
    
currentImage: {
id: null, // IMPORTANT: This is either the actual SRC or the cached image path URL!!!
node: null,
src: null,
title: null,
alt: null,
link: null
},
    
fullContentLoaded: false,
    
node: {
titleContainer: null,
title: null,
author: null,
date: null,
article: null,
contentFeed: null,
contentFull: null
},
    
itemId: null,
    
timer: null,
    
    
isReadabilityActive: function() {
    if (this.node.contentFeed.style.display.toLowerCase() == 'none') {
        return true;
    }
    return false;
},
    
toggleReadability: function() {
    if (this.isReadabilityActive()) {
        this.node.contentFeed.style.display = 'block';
        this.node.contentFull.style.display = 'none';
    } else {
        this.node.contentFeed.style.display = 'none';
        this.node.contentFull.style.display = 'block';
    }
},
    
willLoadFullContent: function() {
    //document.querySelector('.reeder-article .content').style.opacity = 0.95;
},
    
didCancelLoadFullContent: function() {
    //document.querySelector('.reeder-article .content').style.opacity = 1.00;
},
    
didLoadFullContent: function() {
    //document.querySelector('.reeder-article .content').style.opacity = 1.00;
},
    
setReadability: function(json) {
    
    if (this.fullContentLoaded) {
        this.toggleReadability();
        return;
    }
    
    this.fullContentLoaded = true;
    
    
    this.node.contentFull.innerHTML = json.content;
    this.node.contentFull.style.display = 'block';
    this.node.contentFeed.style.display = 'none';
    this.clean();
    
    this.clearCurrentImage();
    
},
    
    
reset: function() {
    
    if (!this.node.title) {
        this.node.titleContainer = document.querySelector('.reeder-article .title-link');
        this.node.title = document.querySelector('.reeder-article .title-link .title');
        this.node.author = document.querySelector('.reeder-article .title-link .author');
        this.node.date = document.querySelector('.reeder-article .title-link .date');
        this.node.article = document.querySelector('.reeder-article');
        this.node.contentFeed = document.querySelector('.reeder-article .content .feed');
        this.node.contentFull = document.querySelector('.reeder-article .content .full');
    }
    
    this.node.titleContainer.href = "";
    this.node.title.innerHTML = "";
    this.node.author.innerHTML = "";
    this.node.date.innerHTML = "";
    
    this.node.contentFeed.style.display = 'block';
    this.node.contentFull.style.display = 'none';
    
    this.node.contentFeed.innerHTML = ""
    this.node.contentFull.innerHTML = "";
    
    this.node.titleContainer.style.display = 'none';
    
    this.images = [];
    this.frames = [];
    
},
    
setContentFeed: function(data) {
    
    if (!this.node.contentFeed) {
        this.node.contentFeed = document.querySelector('.reeder-article .content .feed');
    }

    this.node.contentFeed.innerHTML = data.content;

},
    
    
set: function(item) {

    this.images = [];
    this.frames = [];
    
    this.layoutImages();
    this.layoutFrames();
    
    this.fullContentLoaded = false;
    
    if (!this.node.title) {
        this.node.titleContainer = document.querySelector('.reeder-article .title-link');
        this.node.title = document.querySelector('.reeder-article .title-link .title');
        this.node.author = document.querySelector('.reeder-article .title-link .author');
        this.node.date = document.querySelector('.reeder-article .title-link .date');
        this.node.article = document.querySelector('.reeder-article');
        this.node.contentFeed = document.querySelector('.reeder-article .content .feed');
        this.node.contentFull = document.querySelector('.reeder-article .content .full');
    }
    
    
    this.itemId = item.itemId;
    
    this.node.titleContainer.style.display = 'block';
    this.node.titleContainer.href = item.link;
    this.node.title.innerHTML = item.title;
    this.node.author.innerHTML = item.author;
    this.node.date.innerHTML = item.date;
    
    this.node.contentFeed.style.display = 'block';
    this.node.contentFull.style.display = 'none';
    
    this.node.contentFeed.innerHTML = item.content
    this.node.contentFull.innerHTML = "";
    this.clean();
    
    
    this.clearCurrentImage();
    
    
},
    
    
clearCurrentImage: function() {
    this.currentImage.id = null; // IMPORTANT: This is either the actual SRC or the cached image path URL!!!
    this.currentImage.node = null;
    this.currentImage.src = null;
    this.currentImage.title = null;
    this.currentImage.alt = null;
    this.currentImage.link = null;
},
    
setCurrentImage: function(img) {
    this.currentImage.node = img;
    
    this.currentImage.id = img.src;
    
    if (img.hasAttribute('data-reeder-img-src')) {
        this.currentImage.src = img.getAttribute('data-reeder-img-src');
    } else {
        this.currentImage.src = img.src;
    }
    
    this.currentImage.title = img.getAttribute('title');
    this.currentImage.alt = img.getAttribute('alt');
    if (img.parentNode.tagName.toLowerCase() == 'a') {
        this.currentImage.link = img.parentNode.getAttribute('href');
    } else {
        this.currentImage.link = null;
    }
},
    
tapImage: function(img) {
    this.setCurrentImage(img);
    window.location.href = 'reeder-internal://tap/image';
},
    
    
setCurrentImageAtLocation: function(x, y) {
    var img = document.elementFromPoint(x, y);
    if (img.tagName.toLowerCase() == 'img') {
        this.setCurrentImage(img);
        this.currentImage.src;
    } else {
        this.clearCurrentImage();
    }
},
    
    
currentImageFrame: function() {
    
    
    var img = this.currentImage.node;
    
    if (img) {
        
        var s = document.defaultView.getComputedStyle(img);
        
        var curleft = curtop = 0;
        var obj = img;
        do {
            curleft += obj.offsetLeft;
            curtop += obj.offsetTop;
        } while (obj = obj.offsetParent);
        
        
        var pl = parseInt(s.paddingLeft);
        if (!isNaN(pl)) {
            curleft += pl;
        }
        var pt = parseInt(s.paddingTop);
        if (!isNaN(pt)) {
            curtop += pt;
        }
        
        var bl = parseInt(s.borderLeftWidth);
        if (!isNaN(bl)) {
            curleft += bl;
        }
        var bt = parseInt(s.borderTopWidth);
        if (!isNaN(bt)) {
            curtop += bt;
        }
        
        //        var bl = parseInt(document.body.marginLeft);
        //        if (!isNaN(bl)) {
        //            curleft += bl;
        //        }
        //
        //        var bt = parseInt(document.body.marginTop);
        //        if (!isNaN(bt)) {
        //            curtop += bt;
        //        }
        return "{{" + curleft + "," + curtop + "}, {" + parseInt(s.width) + "," + parseInt(s.height) + "}}";
    }
    
    
},
	
    
images: [],

layoutImages: function() {
    
    
    this.bodyWidth = window.document.documentElement.getBoundingClientRect().width;
    this.contentLeft = document.querySelector('.reeder-article .content').getBoundingClientRect().left;
    this.contentWidth = document.querySelector('.reeder-article .content').getBoundingClientRect().width;
    
    var c = 0;
    for (var i=0; i<this.images.length; i++) {
        var img = this.images[i];
        if (this.layoutImage(img)) {
            c++;
        }
    }
    
    return c;
},
    
frames: [],
    
layoutFrames: function() {
    
    var c = 0;
    for (var i=0; i<this.frames.length; i++) {
        var frame = this.frames[i];
        if (this.layoutFrame(frame)) {
            c++;
        }
    }
    return c;
},
    
layoutImage: function(img) {
    if (img.error__) return;
    if (this.contentWidth <= 0 || this.bodyWidth <= 0) return;
    if (img.naturalWidth > 0) {
        
        var n = img;
        while (n.parentNode) {
            if (n.tagName.toLowerCase() == 'blockquote') {
                return;
            }
            n = n.parentNode;
        }
        
        var w = img.naturalWidth;
        var h = img.naturalHeight;
        

        var minus = '-';
        if (document.defaultView.getComputedStyle(img.parentNode).direction == 'rtl') {
            minus = '';
        }
        
        if (w <= 1 || h <= 1) {
            img.setAttribute('class', 'hidden');
            img.style.left = 'auto';
        }
        else if (w < 50 || h < 50) {
            img.setAttribute('class', 'borderless');
            img.style.left = 'auto';
        }
        else if (w <= reeder.contentWidth) {
            img.setAttribute('class','');
            img.style.left = 'auto';
        }
        else {
            
            if (w < reeder.bodyWidth) {
                w = Math.floor(w/2.0) * 2.0;
                img.setAttribute('class','full');
                img.style.width = w+'px';
                img.style.left = minus+((w-reeder.contentWidth)/2.0)+'px';
            }
            else {
                img.setAttribute('class','full to-border');
                img.style.width = reeder.bodyWidth+'px';
                img.style.left = minus+reeder.contentLeft+'px';
            }
        }
    }
},
    
layoutFrame: function(frame) {
    if (this.contentWidth <= 0 || this.bodyWidth <= 0) return;
    if (frame.getAttribute('data-width') > 0) {
        
        var n = frame;
        while (n.parentNode) {
            if (n.tagName.toLowerCase() == 'blockquote') {
                return;
            }
            n = n.parentNode;
        }

        var w = frame.getAttribute('data-width');
        var h = frame.getAttribute('data-height');
        
        var minus = '-';
//        if (document.defaultView.getComputedStyle(img.parentNode).direction == 'rtl') {
//            minus = '';
//        }

        if (w <= reeder.contentWidth) {
            frame.setAttribute('class','');
            frame.style.left = '0';
            frame.style.width = w+'px';
            frame.style.height = h+'px';
        }
        else {
            
            if (w < reeder.bodyWidth) {
                w = Math.floor(w/2.0) * 2.0;
                frame.setAttribute('class','full');
                frame.style.width = w+'px';
                frame.style.height = h+'px';
                frame.style.left = minus+((w-reeder.contentWidth)/2.0)+'px';
            }
            else {
                frame.setAttribute('class','full to-border');
                frame.style.width = reeder.bodyWidth+'px';
                frame.style.height = Math.floor(h/w*reeder.bodyWidth)+'px';
                frame.style.left = minus+reeder.contentLeft+'px';
            }
        }
    }
},
    
	
    
clean: function() {
    
    this.images = document.querySelectorAll('.reeder-article .content img');
    
    for (var i=0; i<this.images.length; i++) {
        var img = this.images[i];
        
        img.removeAttribute('width');
        img.removeAttribute('height');
        
        img.setAttribute('class','default');
        
        img.onload = function() {
            //reeder.layoutImage(this);
            reeder.layoutImages();
        }
        //reeder.layoutImage(img);
        reeder.layoutImages();
        
        var a = img.parentNode;
        if (a.tagName.toLowerCase() == 'a') {
            a.setAttribute('class', 'reeder-a-img');
        }
        
    }
    
    
    this.frames = document.querySelectorAll('iframe,video,object,embed');
    for (var i=0; i<this.frames.length; i++) {
        var frame = this.frames[i];
        var style = document.defaultView.getComputedStyle(frame);
        var w = parseInt(style.width);
        var h = parseInt(style.height);
        frame.setAttribute('data-width', w);
        frame.setAttribute('data-height', h);
        //reeder.layoutFrame(frame);
        reeder.layoutFrames();
    }

    
//    var regex = new RegExp('.*://([^/]*)(/?.*)');
//    
//    var frames = document.querySelectorAll('.reeder-article .content iframe');
//    for (var i = 0; i < frames.length; i++) {
//        var frame = frames[i];
//        var src = frame.src;
//        var a = document.createElement('a');
//        a.setAttribute('class', 'reeder-a-iframe');
//        a.href = src;
//        
//        var matches = regex.exec(frame.src);
//        var html = '';
//        if (matches.length >= 2) {
//            if (matches[1].substring(0, 4) == 'www.') {
//                html += "<span class=\"host\">" + matches[1].substring(4) + "</span>";
//            } else {
//                html += "<span class=\"host\">" + matches[1] + "</span>";
//            }
//        }
//        if (matches.length >= 3) {
//            html += "<span class=\"path\">" + matches[2] + "</span>";
//        }
//        
//        if (html == '') {
//            html = "<span class=\"path\">" + src + "</span>";
//        }
//        
//        a.innerHTML = html;
//        frame.parentNode.insertBefore(a, frame);
//        frame.parentNode.removeChild(frame);
//    }
    
    
    var styles = document.querySelectorAll('.reeder-article .content style');
    for (var i = 0; i < styles.length; i++) {
        var s = styles[i];
        s.parentNode.removeChild(s);
    }
    var scripts = document.querySelectorAll('.reeder-article .content script');
    for (var i = 0; i < scripts.length; i++) {
        var s = scripts[i];
        s.parentNode.removeChild(s);
    }
    
    
    
},
    
    
    
triggerTapAtLocation: function(x__,y__) {
    
    var link = 0;
    var img = 0;
    
    var x = x__;
    var y = y__;
    
    var d = 12.0;
    
    for (var h=0; h<3; h++) {
        for (var v=0; v<3; v++) {
            
            if (h==1) {
                x = x__ - d;
            }
            else if (h==2) {
                x = x__ + d;
            }
            
            if (v==1) {
                y = y__ - d;
            }
            else if (v==2) {
                y = y__ + d;
            }
            
            
            var elem = document.elementFromPoint(x,y);
            
            do {
                
                if (elem == document.body) {
                    break;
                }
                
                if (elem.tagName.toLowerCase() == 'img' && x == x__ && y == y__) {
                    img = elem;
                    break;
                }
                else if (elem.tagName.toLowerCase() == 'a') {
                    link = elem;
                    break;
                }
                
                elem = elem.parentNode;
                
            } while (elem);
            
            if (link||img) break;
            
        }
        
        if (link||img) break;
        
    }
    
    
    if (link) {
        var href = 'reeder-internal://tap/link/'+link.getAttribute('href');
        window.location.href = href;
        return 1;
    }
    else if (img) {
        this.tapImage(img);
        return 1;
    }
    return 0;
},
    
    
layoutOnWindowResize: true,
    
dummy: function() {}
}

window.onresize = function(event) {
    if (reeder.layoutOnWindowResize) {
        reeder.layoutImages();
        reeder.layoutFrames();
    }
}

